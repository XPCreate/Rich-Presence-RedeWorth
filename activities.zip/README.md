# Atividade Rede Worth `v1.8.6`  
### Apenas para fins de divulgação.  

## 🔹 O que foi atualizado:  
- Melhorias no código.  
- Correção na conexão com a api.
- `TypeError: fetch failed` corrigido;

## 🔹 Como usar:  
1. Extraia os arquivos para uma pasta.  
2. Acesse a pasta `start`.  
3. Escolha a pasta correspondente ao seu sistema operacional.  
4. Clique duas vezes no arquivo `setup`. Caso o **Node.js** não esteja instalado, ele será instalado automaticamente. Após a instalação, uma nova janela será aberta e o sistema será executado.  
5. Para abrir o sistema posteriormente, siga o mesmo processo, mas execute o arquivo `run`.  

✅ Pronto! O sistema estará funcionando.