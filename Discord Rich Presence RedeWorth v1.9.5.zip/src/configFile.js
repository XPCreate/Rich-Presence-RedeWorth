module.exports = {
    nickname: "Desconhecido",
    environment: "Production" // Development || Production
}