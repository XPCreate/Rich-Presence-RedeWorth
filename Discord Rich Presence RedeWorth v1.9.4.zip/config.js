module.exports = {
    nickname: "Desconhecido",
    environment: "Production"
}